/* Windows PC collector. Build: cl /O2 /W4 /MT collect.c */
#define _CRT_SECURE_NO_WARNINGS
#define _WIN32_WINNT 0x0600
#include <windows.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <direct.h>

typedef struct {
    uint32_t dies, blocks;
    uint64_t rows;
    ULONGLONG last_record;
} Snapshot;

static int number(const char *s, uint32_t limit, uint32_t *out)
{
    uint64_t n = 0;
    if (!*s) return 0;
    for (; *s; ++s) {
        if (*s < '0' || *s > '9') return 0;
        n = n * 10 + (*s - '0');
        if (n > limit) return 0;
    }
    *out = (uint32_t)n;
    return 1;
}

/* Return 1 on verified END, 0 to continue, -1 on invalid input. */
static int record(char *line, Snapshot *s, FILE *csv)
{
    char *v[7], *p;
    int count = 1;
    uint32_t die, block, erase, age, bad, free_flag, end;
    if (strncmp(line, "META_", 5)) return 0;
    v[0] = line;
    while ((p = strchr(v[count - 1], ',')) != NULL) {
        if (count == 7) return -1;
        *p = '\0';
        v[count++] = p + 1;
    }
    s->last_record = GetTickCount64();
    if (!strcmp(v[0], "META_BEGIN") && count == 4 && !s->dies) {
        if (strcmp(v[1], "1") || !number(v[2], UINT32_MAX, &s->dies) ||
            !number(v[3], UINT32_MAX, &s->blocks) || !s->dies || !s->blocks)
            return -1;
        return 0;
    }
    if (!s->blocks) return -1;
    if (!strcmp(v[0], "META_END") && count == 2) {
        return number(v[1], UINT32_MAX, &end) && end == s->rows &&
               s->rows == (uint64_t)s->dies * s->blocks ? 1 : -1;
    }
    if (strcmp(v[0], "META_BLOCK") || count != 7 ||
        !number(v[1], s->dies - 1, &die) || !number(v[2], s->blocks - 1, &block) ||
        (uint64_t)die * s->blocks + block != s->rows ||
        !number(v[3], 65535, &erase) ||
        (strcmp(v[4], "NA") && !number(v[4], UINT32_MAX, &age)) ||
        !number(v[5], 1, &bad) || !number(v[6], 1, &free_flag)) return -1;
    if (fprintf(csv, "%u,%u,%u,%s,%u,%u\r\n", die, block, erase, v[4], bad, free_flag) < 0)
        return -1;
    ++s->rows;
    return 0;
}

static HANDLE open_port(const wchar_t *name, const wchar_t *rate)
{
    wchar_t path[40], *end;
    DCB config = {0};
    COMMTIMEOUTS timeouts = {0};
    HANDLE h;
    unsigned long baud = wcstoul(rate, &end, 10);
    if (!baud || *end || _wcsnicmp(name, L"COM", 3) || !name[3] ||
        wcsspn(name + 3, L"0123456789") != wcslen(name + 3) ||
        swprintf_s(path, 40, L"\\\\.\\%ls", name) < 0) return INVALID_HANDLE_VALUE;
    h = CreateFileW(path, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    if (h == INVALID_HANDLE_VALUE) return h;
    config.DCBlength = sizeof(config);
    if (!GetCommState(h, &config)) goto failed;
    config.BaudRate = baud;
    config.ByteSize = 8;
    config.Parity = NOPARITY;
    config.StopBits = ONESTOPBIT;
    config.fBinary = TRUE;
    config.fParity = config.fOutxCtsFlow = config.fOutxDsrFlow = FALSE;
    config.fOutX = config.fInX = config.fDsrSensitivity = FALSE;
    config.fNull = config.fAbortOnError = config.fErrorChar = FALSE;
    config.fDtrControl = DTR_CONTROL_DISABLE;
    config.fRtsControl = RTS_CONTROL_DISABLE;
    timeouts.ReadIntervalTimeout = 30;
    timeouts.ReadTotalTimeoutConstant = 250;
    timeouts.WriteTotalTimeoutConstant = 5000;
    if (SetCommState(h, &config) && SetCommTimeouts(h, &timeouts) &&
        PurgeComm(h, PURGE_RXCLEAR)) return h;
failed:
    CloseHandle(h);
    return INVALID_HANDLE_VALUE;
}

int wmain(int argc, wchar_t **argv)
{
    HANDLE port = INVALID_HANDLE_VALUE;
    FILE *input = NULL, *log = NULL, *csv = NULL;
    Snapshot s = {0};
    char buf[4096], line[1024];
    size_t used = 0;
    int status = 0, ok = 0, replay;
    DWORD n = 0, i;
    if (argc != 4) {
        fputs("Usage: collect.exe COM4 115200 run01\n"
              "       collect.exe --replay uart.log new_run\n", stderr);
        return 2;
    }
    replay = !wcscmp(argv[1], L"--replay");
    if (replay) input = _wfopen(argv[2], L"rb");
    else port = open_port(argv[1], argv[2]);
    if (!input && port == INVALID_HANDLE_VALUE) {
        fputs("Cannot open input. Check port, baud and SDK Terminal connection.\n", stderr);
        return 1;
    }
    if (_wmkdir(argv[3]) || _wchdir(argv[3])) {
        fputs("Provide a NEW output directory under an existing parent.\n", stderr);
        goto done;
    }
    log = fopen("uart.log", "wb");
    csv = fopen("blocks.partial", "wb");
    if (!log || !csv || fputs("die,virtual_block,erase_count,age,bad,free\r\n", csv) < 0)
        goto done;
    if (!replay && (!WriteFile(port, "export\r\n", 8, &n, NULL) || n != 8)) goto done;
    s.last_record = GetTickCount64();
    while (!status) {
        if (replay) {
            n = (DWORD)fread(buf, 1, sizeof(buf), input);
            if (!n) break;
        } else if (!ReadFile(port, buf, sizeof(buf), &n, NULL) ||
                   GetTickCount64() - s.last_record > 15000) break;
        if (fwrite(buf, 1, n, log) != n) break;
        for (i = 0; i < n && !status; ++i) {
            if (buf[i] == '\n') {
                if (used && line[used - 1] == '\r') --used;
                line[used] = '\0';
                status = record(line, &s, csv);
                used = 0;
            } else if (used == sizeof(line) - 1 || !buf[i]) status = -1;
            else line[used++] = buf[i];
        }
    }
    if (fclose(csv)) status = -1;
    csv = NULL;
    if (fclose(log)) status = -1;
    log = NULL;
    if (status == 1 && !rename("blocks.partial", "blocks.csv")) {
        printf("%llu blocks -> blocks.csv\n", (unsigned long long)s.rows);
        ok = 1;
    }
done:
    if (csv) fclose(csv);
    if (log) fclose(log);
    if (input) fclose(input);
    if (port != INVALID_HANDLE_VALUE) CloseHandle(port);
    if (!ok) fputs("Collection failed; no completed CSV was published.\n", stderr);
    return ok ? 0 : 1;
}
